#encoding=utf-8
conda activate rtest3
cd /home/main/stu/ryt/MONAI/nnUNet3/
nohup nnUNet_train 3d_fullres  nnUNetTrainerV2  26  1  --npz  &